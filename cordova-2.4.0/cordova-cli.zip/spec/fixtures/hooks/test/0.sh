echo "this is script 0 in `pwd`";
