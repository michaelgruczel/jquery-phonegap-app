import com.yourapp.R;

import android.app.*;

public class SomethingWithR {
}
