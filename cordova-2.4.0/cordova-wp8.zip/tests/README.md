Tests Have Moved
===

Tests now live in the MobileSpec repo at:
https://github.com/apache/cordova-mobile-spec

You will need to create a new project, and add the mobile-spec files to it to run the tests.